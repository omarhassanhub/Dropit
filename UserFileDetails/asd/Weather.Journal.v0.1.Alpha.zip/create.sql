
date DATE PRIMARY KEY, 
location VARCHAR, 
temperature INT NOT NULL, 
pressure INT, 
humidity INT, 
dayLength ARRAY, 
conditions VARCHAR, 
description VARCHAR,

CHECK(date <= CURRENT_DATE()),
CHECK(temperature > -100 AND temperature < 100),
CHECK(humidity >= 0 AND humidity <= 100)
